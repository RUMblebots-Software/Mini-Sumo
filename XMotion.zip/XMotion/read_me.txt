This main file directory should be inside Documents/Arduino/libraries.
